# ten98 code system

The implementation library for repeated ten98 features. Other sessions should adopt its tested code and complete reference implementations before writing another version. The separate [design system](https://github.com/Ten98-IO-Company/ten98-design-system) owns React presentation.

Start with the [feature catalog](https://github.com/Ten98-IO-Company/ten98-code-system/blob/main/features/catalog.json), [adoption guide](https://github.com/Ten98-IO-Company/ten98-code-system/blob/main/docs/FEATURE-ADOPTION.md) and [implementation brief](https://github.com/Ten98-IO-Company/ten98-code-system/blob/main/IMPLEMENTATION-BRIEF.md). Portable code is imported from `@ten98/runtime` or `@ten98/ui`. Stack-bound features include immutable complete source bundles, entrypoints, tests, integration requirements and known issues. A source reference or passing unit check alone is not a production reliability claim.

Keep one maintained implementation for each supported feature and stack. Promote proven app code with its dependencies, migrations, security boundaries and checks; preserve attribution. Avoid speculative frameworks, fragment-only templates and silently diverging copies. Track defects and adoption work in [Issues](https://github.com/Ten98-IO-Company/ten98-code-system/issues) and the [Project](https://github.com/orgs/Ten98-IO-Company/projects/1).

## Common implementation

Import these functions from `@ten98/runtime`:

- `workspaceRoles`, `mayGrantWorkspaceRole(actor, role)` and `mayManageWorkspaceMember(actor, previousRole, nextRole?)` own the four membership roles and grant rules. Owners manage all known roles; administrators manage editors/viewers; other or unknown actors cannot grant access. Member changes check both saved and requested roles; omit the next role for removal. Database tenant checks, last-owner locks and instance-operator authority remain app-owned.

- `readResponseText(response, { maxBytes, signal, preserveBOM })` counts received bytes, rejects malformed UTF-8 and cancels/releases the reader on completion, failure or abort. A leading UTF-8 BOM is stripped by default; set `preserveBOM: true` to retain it when replacing a Buffer decoder, so JSON parsing and exact-empty checks keep their existing behavior. Callers retain JSON/schema parsing, status policy and safe errors.
- `openRouterFetch(path, { apiKey, title, body, signal, metadata }, send)` uses the fixed HTTPS OpenRouter API, rejects redirects, omits ambient credentials and makes one request. GET defaults to a 10-second deadline; JSON POST defaults to 60 seconds. Pass a signal when requests share one deadline. Paid authorization, idempotency, receipts and reconciliation remain app-owned.
- `oidcEndpoint(raw, { issuer, allowHttp })` validates HTTPS URLs without credentials or fragments; issuers also reject queries. `allowHttp` is for an explicitly admitted test fixture. Apps retain framework PKCE/state/nonce/signature checks, single-use transactions, identity linking, MFA and endpoint/DNS policies.

## Architecture contract

[architecture.json](architecture.json) is the canonical declaration of shared versions, package pins and approved runtime and development dependencies. [check.mjs](check.mjs) checks those declarations and the test/build gates:

```sh
node check.mjs ../ten98-design-system ../ten98-campaign ../ten98-discover .
```

Campaign, Discover and the design-system development tools share Node 24, React, TypeScript and Vite versions. The architecture CLI first checks the executing Node version against the canonical range, before reading consumer manifests or launching compilers; declaring an approved engine does not excuse running a different Node version. Their existing npm/pnpm lockfiles remain installation inputs. Application consumers use the same accepted immutable UI and runtime archives in `vendor`; standalone Docker builds require no sibling checkout or private registry. A design-system source version can be ahead of the last accepted consumer archive.

Shared presentation belongs in `@ten98/ui`; common server mechanisms belong here. Frontends call their app's authenticated API. Provider keys, database access and paid dispatch stay on the server. Reuse installed frameworks and native platform capabilities before adding a library. Runtime dependency or version changes require updating this contract and checking affected consumers together.

Apply the same review to development dependencies: a framework or server hidden in `devDependencies` still changes the stack. Each profile lists its approved tools and declared versions. Overrides, resolution substitutions, local dependency patches and bundled dependencies are rejected; introduce an intentional dependency change through this contract and an accepted immutable release. The existing UI browser-tool version range remains an explicit approved declaration, with its installed version fixed by the lockfile.

Every required test/build script must begin with `npm run check:architecture &&`, `pnpm check:architecture &&` or `pnpm run check:architecture &&`, followed by its actual checks. Use a simple inline `&&` chain; optional pre-script hooks, echoed command names, background commands and failure-masking shell operators do not satisfy the gate. For profiles with a source-language policy, this gate also invokes the installed, pinned TypeScript compiler directly. It reads effective options and the resolved program for every declared compiler project (including Campaign's backend project), verifies production source coverage, and runs semantic checking with `--noEmit`. A failed check stops test/build before their remaining commands.

Both Node apps reuse `@ten98/ui` authentication layout and sidebar keyboard/focus behavior. Their identity adapters implement the [feature contracts](https://github.com/Ten98-IO-Company/ten98-code-system/blob/main/docs/FEATURE-CONTRACTS.md), including permanent invitation revocation, explicit ownership transfer and fragment-based invitation links. Search uses explicit displayed fields while retaining each operation's native scope.

Current retained adapters are explicit: Campaign uses Node HTTP, SQLite and `openid-client`; Discover uses TanStack Start/Nitro, PostgreSQL/Drizzle and Better Auth. Their storage, routing and identity controllers have not been unified. Shared primitives preserve their distinct security and accounting contracts. The checker verifies declared consistency and configured source typing; it does not prove framework equivalence, runtime call coverage, OIDC interoperability or release readiness.

New authenticated Node applications use the existing Discover architecture by default: TanStack Start/Nitro, Better Auth, PostgreSQL/Drizzle and pg-boss, with shared runtime primitives and @ten98/ui presentation. Campaign's Node HTTP/SQLite/openid-client stack remains a retained migration adapter tracked in [issue #7](https://github.com/Ten98-IO-Company/ten98-code-system/issues/7). This is the target for new work, not a claim that current applications have equivalent capabilities.

Docker applications use project-scoped volumes, private database networking, loopback host bindings, native `init`, bounded health probes and a 30-second stop grace. Discover's separate migration/worker lifecycle remains necessary. Image pins and service layout remain deployment-owned; there is no Compose generator or universal service template.

Managed web applications target Docker Compose on OpenShip-managed Debian Linux. Prefer a reviewed, digest-pinned Node 24 Debian slim image for Node services and keep the same image across web, worker and migration entrypoints. Shared development tooling uses Node; any POSIX shell belongs to a documented Linux deployment boundary, never a Windows-only runtime requirement. Container and migration checks must run against the chosen image before adoption.

Drizzle is the default TypeScript database integration for the PostgreSQL stack. Keep versioned SQL migrations for database constraints, triggers and routines that a schema declaration does not replace. An ORM or migration-runner change must preserve existing checksums, transaction and locking behavior, data, identities and upgrade tests. New application production logic uses checked TypeScript. The checker inventories source-bearing files across the application: new `api`/`lib` folders and new native scripts require canonical classification instead of silently escaping the production roots. Exact native/configuration/public-file exceptions and explicit test/generated/vendor artifact directories are recorded in the same policy; these boundaries do not establish complete dynamic-import or live runtime coverage. The canonical source policy rejects new JavaScript in production roots, excluded TypeScript, disabled strict options and authored `@ts-nocheck`. Discover's exact generated route-tree exception retains its generator marker. Campaign's 41 retained JavaScript paths after the seed/schedule migration (including the foundation instance-operator adapter) remain untyped migration gaps owned by its app team in [issue #14](https://github.com/Ten98-IO-Company/ten98-code-system/issues/14); the exception list is not completed TypeScript adoption. Generated runtime ESM output, the retained native canonical checker, test/configuration scripts and generated/upstream public/distribution assets remain explicit boundaries outside this production-source coverage claim. Preserve their URLs, runtime contracts and notices; changing extensions alone does not add checking. Campaign Docker builds must copy `server` alongside `src` and `shared` before the architecture/build gate, so missing production roots cannot pass.

`ten98-io` remains a native Cloudflare Worker/static site; its D1, email and rate-limiting bindings need no React, Node server controllers or Compose. Its canonical profile uses Wrangler plus build-only TypeScript, `@ten98/ui` token CSS and the `@ten98/runtime` architecture CLI. React and React DOM are exact canonical development pins that satisfy the UI package peers; the static browser pages consume CSS only and import no React application code. Build, check and test scripts run that CLI first. `tsconfig.tooling.json` strictly checks `scripts/*.mts`, including the token resolver test; exact existing Worker, browser and native-check JavaScript paths remain behavioral-test boundaries. The checker rejects newly authored JavaScript and uncompiled TypeScript, but does not inspect imports inside retained JavaScript or prove live Cloudflare behavior. Actual consumer archive/lock, generated token/license bytes, native tests and browser checks remain adoption requirements. Native Cloudflare applications remain an explicit exception to the authenticated Node default. Third-party infrastructure retains upstream stacks. `ten98-connect` is not built yet and has no implementation audit claim. Reuse this shared contract before building new apps; inventory their actual implementation and add the applicable profile before claiming suite coverage.

## Verify and release

```sh
npm test
npm pack --dry-run
npm pack
```

The runtime API is authored in `src/index.mts`. `npm run build` runs the canonical architecture gate and pinned TypeScript compiler with strict checking before emitting the existing `index.mjs` and `index.d.mts` public entrypoints. `npm test` and `npm pack` build before consuming those outputs. TypeScript is a development tool; there is no third-party runtime dependency. The native canonical checker and tests remain a separately owned JavaScript migration gap in issue #14. Inspect the archive, copy the same bytes into each consumer's `vendor`, update its manifest and existing lockfile together, then run the consumer's architecture, offline, type and build checks. Retain earlier releases unchanged. Changed shared code needs a new package version; never overwrite consumed bytes. Application publication and deployment are separate actions.

Specialized network readers remain when they enforce additional contracts, such as exact content-length evidence, binary MCP output or inbound request error semantics. Extract them only when every existing guard can be preserved with less code.

### Release identity gate

Future releases use normal `X.Y.Z` package versions and annotated `vX.Y.Z` Git tags. Keep historical preview/evidence tags and independent protocol/API/schema versions unchanged. Ordinary architecture checks do not require a release tag.

```sh
node check.mjs --release . --tag vX.Y.Z --commit QUALIFIED_COMMIT_SHA
```

Release mode reads the actual annotated tag object, peeled commit and checked-out HEAD, then reads `package.json` and both root version/name records in `package-lock.json` from that commit. Supply the independently qualified full commit SHA, not a value derived from the tag being checked. It rejects lightweight tags, version metadata/prereleases, aliases, mismatched package/lock identity and another checked-out commit. The proposed tag-push CI hook uses the event's commit and rejects updates/deletions rather than treating a moved tag as a new release. GitHub's [push event documentation](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#push) defines that commit context.

Use `--tag-object SHA` with an independently retained tag-object receipt to detect annotation replacement or movement, including movement to the same commit. `--event FILE` accepts the original GitHub push event and requires a new, unforced tag creation. Without either, history is explicitly unverified. A local checkout cannot establish remote publication history; deletion followed by recreation still requires protected tags and publisher review of retained release receipts. Do not manufacture a receipt from the current tag and describe it as immutability verification.

Optional `--archive FILE` reads its real package metadata using native `tar`, checks the npm filename and computes SHA256 from the supplied bytes; `--archive-sha256 SHA` compares those bytes against an independently retained digest. This does not prove that every archive member matches the qualified source or that remote release assets are unchanged. No archive is built or modified by the gate. Native Git and, for archives, tar must be installed.

Publication remains separately gated: the release owner verifies the GitHub title equals `vX.Y.Z`, prerelease is false, remote tag/assets remain immutable, and source-to-archive closure is complete. Apps must collect actual OCI version/revision labels and image digest plus the running browser's displayed version. Caller-supplied labels are not image or browser proof; missing evidence remains unverified.
